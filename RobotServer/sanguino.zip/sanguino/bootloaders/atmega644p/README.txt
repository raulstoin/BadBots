Note: This bootloader support ATmega644, ATmega644P and ATmega324P.
To build, set PROGRAM and MCU_TARGET in the Makefile according to your target device.

